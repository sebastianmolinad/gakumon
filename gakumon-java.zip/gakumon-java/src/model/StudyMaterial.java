
package model;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author Sebastian Molina, Gabriel Alvarez, Julian Casallas
 */
public class StudyMaterial {
    private String filename;
    private String subject;
    private String faculty;
    private String teacher;
    private int year;
    private String semester;
    private int term; //First-term, mid-term, -third-, final
    private String type; //Exam, workshop, class notes
    private File file;
    private String uploadedBy;
    private Calendar.Builder dateUploaded;
    private ArrayList<String> topics;
    private ArrayList<Comment> comments;
    private Boolean reported; //For non-study material management
    
    public StudyMaterial() {
        this.filename = "";
        this.subject = "";
        this.faculty = "";
        this.teacher = "";
        this.year = 0;
        this.semester = "";
        this.term = 0;
        this.type = "";
        this.file = new File("");
        this.uploadedBy = "";
        this.dateUploaded = new Calendar.Builder();
        this.topics = new ArrayList();
        this.comments = new ArrayList();
        this.reported = false;
    }

    public StudyMaterial(String filename, String subject, String faculty, String teacher, int year, 
            String semester, int term, String type, File file, String whoUploaded, 
            Calendar.Builder dateUploaded, ArrayList<String> topics, ArrayList<Comment> comments, Boolean reported) {
        this.filename = filename;
        this.subject = subject;
        this.faculty = faculty;
        this.teacher = teacher;
        this.year = year;
        this.semester = semester;
        this.term = term;
        this.type = type;
        this.file = file;
        this.uploadedBy = whoUploaded;
        this.dateUploaded = dateUploaded;
        this.topics = topics;
        this.comments = comments;
        this.reported = reported;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public int getTerm() {
        return term;
    }

    public void setTerm(int term) {
        this.term = term;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getUploadedBy() {
        return uploadedBy;
    }

    public void setUploadedBy(String uploadedBy) {
        this.uploadedBy = uploadedBy;
    }

    public Calendar.Builder getDateUploaded() {
        return dateUploaded;
    }

    public void setDateUploaded(Calendar.Builder dateUploaded) {
        this.dateUploaded = dateUploaded;
    }

    public ArrayList<String> getTopics() {
        return topics;
    }

    public void setTopics(ArrayList<String> topics) {
        this.topics = topics;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public void setComments(ArrayList<Comment> comments) {
        this.comments = comments;
    }

    public Boolean getReported() {
        return reported;
    }

    public void setReported(Boolean reported) {
        this.reported = reported;
    }
    
    
    
}
