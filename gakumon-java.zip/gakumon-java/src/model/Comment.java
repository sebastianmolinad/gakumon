
package model;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author Sebastian Molina, Gabriel Alvarez, Julian Casallas
 */
public class Comment {
    private String whoCommented; //Who wrote the comment
    private BufferedImage whoCommentedPic; //Who commented profile pic
    private Calendar.Builder commentDate;
    private String comment;
    private ArrayList<Comment> replies;
    
    public Comment() {
        this.whoCommented = "";
        this.whoCommentedPic = whoCommentedPic;
        this.commentDate = new Calendar.Builder();
        this.comment = "";
        this.replies = new ArrayList();
    }

    public Comment(String whoCommented, BufferedImage whoCommentedPic, Calendar.Builder commentDate, String comment, ArrayList<Comment> replies) {
        this.whoCommented = whoCommented;
        this.whoCommentedPic = whoCommentedPic;
        this.commentDate = commentDate;
        this.comment = comment;
        this.replies = replies;
    }

    public String getWhoCommented() {
        return whoCommented;
    }

    public void setWhoCommented(String whoCommented) {
        this.whoCommented = whoCommented;
    }

    public BufferedImage getWhoCommentedPic() {
        return whoCommentedPic;
    }

    public void setWhoCommentedPic(BufferedImage whoCommentedPic) {
        this.whoCommentedPic = whoCommentedPic;
    }

    public Calendar.Builder getCommentDate() {
        return commentDate;
    }

    public void setCommentDate(Calendar.Builder commentDate) {
        this.commentDate = commentDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public ArrayList<Comment> getReplies() {
        return replies;
    }

    public void setReplies(ArrayList<Comment> replies) {
        this.replies = replies;
    }   
    
}
