
package model;

/**
 *
 * @author Sebastian Molina, Gabriel Alvarez, Julian Casallas
 */
public class OuterSpaceResidents {
    private String name;
    private String homeGalaxy;
    private long addressFromEarth; 
    private String addressMeasureUnit; //Location from Earth measure unit
    private String message;
    
    public OuterSpaceResidents() {
        this.name = "";
        this.homeGalaxy = "";
        this.addressFromEarth = 0;
        this.addressMeasureUnit = "";
        this.message = "";
    }

    public OuterSpaceResidents(String name, String homeGalaxy, long addressFromEarth, String addressMeasureUnit, String message) {
        this.name = name;
        this.homeGalaxy = homeGalaxy;
        this.addressFromEarth = addressFromEarth;
        this.addressMeasureUnit = addressMeasureUnit;
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHomeGalaxy() {
        return homeGalaxy;
    }

    public void setHomeGalaxy(String homeGalaxy) {
        this.homeGalaxy = homeGalaxy;
    }

    public long getAddressFromEarth() {
        return addressFromEarth;
    }

    public void setAddressFromEarth(long addressFromEarth) {
        this.addressFromEarth = addressFromEarth;
    }

    public String getAddressMeasureUnit() {
        return addressMeasureUnit;
    }

    public void setAddressMeasureUnit(String addressMeasureUnit) {
        this.addressMeasureUnit = addressMeasureUnit;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    


    
    
}
