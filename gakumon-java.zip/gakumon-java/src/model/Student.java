
package model;

/**
 *
 * @author Sebastian Molina, Gabriel Alvarez, Julian Casallas
 */
public class Student extends User{
    private String university;
    private String career;
    private Boolean suspended;
    
    public Student() {
        this.university = "";
        this.career = "";
        this.suspended = false;
    }

    public Student(String university, String career, Boolean suspended) {
        this.university = university;
        this.career = career;
        this.suspended = suspended;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public String getCareer() {
        return career;
    }

    public void setCareer(String career) {
        this.career = career;
    }

    public Boolean getSuspended() {
        return suspended;
    }

    public void setSuspended(Boolean suspended) {
        this.suspended = suspended;
    }
    


}
