
package model;

/**
 *
 * @author Sebastian Molina, Gabriel Alvarez, Julian Casallas
 */
public class Admin extends User{   
}
